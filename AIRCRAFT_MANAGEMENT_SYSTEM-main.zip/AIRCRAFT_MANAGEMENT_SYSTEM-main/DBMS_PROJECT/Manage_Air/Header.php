<?php
	$conn=oci_connect("ID_53","sunamrcc49b","localhost/XE");
	// if($conn){
	// 	echo "success";
	// }
?>
